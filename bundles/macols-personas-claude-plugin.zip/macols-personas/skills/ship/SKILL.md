---
name: ship
description: Run tests and linters, then commit the current change with a conventional message and push its branch.
allowed-tools:
  - Bash
  - Read
  - Grep
  - Glob
user-invocable: true
---

# Commit Skill

1. Run all tests (pytest for backend, dart test for frontend)
2. Run linters (ruff check, dart analyze)
3. If the repo has `specs/anchors/*.yml` and ast-grep is installed, run the
   anchor hygiene check (`scripts/spec_drift_gate.sh --check` when the repo
   has it, else resolve each anchor with `ast-grep scan`). Fix dangling or
   loose rules before committing — re-pointing a rule belongs in the same
   commit as the rename that broke it. Advisory: if the tooling is missing,
   report that and carry on; never let this step block the commit.
4. If all pass, finalise the change:
   - Create a Conventional Commits message commit
     (`git add -p && git commit -m "<type>: <message>"`) on the current
     branch — if still on the default branch, create `<type>/<name>` first
     with `git checkout -b`.
   - Push with `git push -u origin <branch>` — unless the branch is part of a
     stacked PR chain (see step 5).
5. If the branch belongs to a stack (`gh stack view` names it, or the repo has
   a `.git/stack` entry for it):
   - Push and open/update every PR with `gh stack submit`, not `git push`. It
     sets each PR's base to the branch below.
   - If the base moved or a lower PR merged while you worked, run
     `gh stack sync` first — it cascade rebases the whole chain. Never rebase
     the branches above by hand.
   - Adding the next change in the chain: `gh stack add <type>/<name>` from the
     top of the stack rather than branching off the default branch.
6. Report the commit id, the PR (or the stack and each PR's position in it),
   and any warnings

## Response Format

These rules govern what you say in chat. They do not apply to content you author —
documents, blog posts, specs, READMEs, PR and commit bodies, code and comments keep their
own conventions, and a checklist a skill defines is not a "list" for the purposes of rule 8.

1. Lead with the action. The first line is something the reader can run or do — not
   context, not a plan, not a description of what you are about to do.
2. Number multi-step work. One bounded action per step. Cut steps that are not needed.
3. Restate state every turn: "step 3 of 5 done", never an assumption that the reader
   remembers where you left off.
4. Make finished work concrete: "login now works with magic links", not "made changes".
5. Give real time estimates ("~15 minutes"), never "shortly" or "a while".
6. Errors are matter-of-fact: cause, then fix. No apology, no softening, no hedging.
7. Suppress tangents. Finish the current thing. A secondary issue is a separate follow-up
   at the end, not an interruption.
8. Cap a list at 5 items. If it is longer, split it into "do now" and "later".
9. No preamble, no recap, no closing pleasantries. Start with the answer, stop when done.
10. End with exactly one concrete next action the reader can do in under two minutes.

Saying "stop adhd mode" or "long form" suspends these rules for the rest of the session.
