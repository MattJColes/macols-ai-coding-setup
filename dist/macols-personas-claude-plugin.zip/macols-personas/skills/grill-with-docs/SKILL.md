---
name: grill-with-docs
description: Use before a code change in a repo - grills Matt about the plan in numbered rounds like grill-me, and builds the project's domain model as it goes, sharpening terminology into GLOSSARY.md and recording hard-to-reverse decisions (in the OpenSpec change's design.md where the repo uses OpenSpec, otherwise an ADR). Triggers on "grill with docs", "grill me on this change", "sharpen the domain language". Plans with no codebase belong to grill-me; designing a whole system belongs to architecture.
user-invocable: true
---

A grilling session on a code change that also builds the project's domain
model. Two disciplines run at once: the grilling loop decides _what_ to ask
next, and domain modelling sharpens the words the answers use and writes them
down the moment they settle. Writing the glossary and decision records is part
of the session; acting on the plan is not.

## The grilling loop

Interview the user relentlessly until you reach a shared understanding. Map this as a **design tree**: every decision branches into the decisions that hang off it.

Work the tree in **rounds**. The **frontier** is every decision whose prerequisites are already settled: the questions you can ask _now_ without guessing at answers you haven't heard yet. Ask the whole frontier in one round: number each question and give your recommended answer. Then wait for the user's answers before the next round.

Format a round like so:

```
❓ **Q1** - **<question title>**: <question body, might be multiple paragraphs, including multiple choices>

➡️ <your recommended answer>

---

❓ **Q2** - **<question title>**: <question body, might be multiple paragraphs, including multiple choices>

➡️ <your recommended answer>
```

Word each question so "yes" accepts your recommended answer.

Each round the user answers reshapes the tree: settled decisions push the frontier outward and unblock questions that depended on them. Recompute the frontier and ask the next round. A question whose answer depends on another question still open in this round belongs to a _later_ round, not this one.

Finding _facts_ is your job, never the user's. When a frontier question needs a fact from the environment (filesystem, tools, etc.), dispatch a sub-agent to find it (or look it up yourself where the tool has no sub-agents); don't ask the user for anything you could look up yourself. Don't block on it: a running exploration is an unsettled prerequisite, so only the questions downstream of it wait for the sub-agent to report; ask the rest of the frontier now. The _decisions_ are the user's: put each to them and wait.

The session is done when the frontier is empty: every branch of the design tree visited, nothing left silently assumed. Do not act on it until the user confirms you have reached a shared understanding.

## Domain modelling

Actively build and sharpen the project's domain model as you design: challenge
terms, invent edge-case scenarios, and write the glossary and decisions down
the moment they crystallise. Merely _reading_ `GLOSSARY.md` for vocabulary is
not this; this is for when the model is changing.

### File structure

Most repos have a single context: one `GLOSSARY.md` at the root. If a
`GLOSSARY-MAP.md` exists at the root, the repo has several contexts and the map
points to each context's own `GLOSSARY.md`. When several exist, infer which one
the topic belongs to; if unclear, ask. Create files lazily, only when you have
something to write. Format and the single vs multi-context layout are in
`references/glossary-format.md`.

### Challenge against the glossary

When the user uses a term that conflicts with the existing language in
`GLOSSARY.md`, call it out immediately: "Your glossary defines 'cancellation'
as X, but you seem to mean Y. Which is it?"

### Sharpen fuzzy language

When the user uses vague or overloaded terms, propose a precise canonical
term: "You're saying 'account': do you mean the Customer or the User? Those
are different things."

### Discuss concrete scenarios

When domain relationships come up, stress-test them with specific scenarios.
Invent scenarios that probe edge cases and force the user to be precise about
the boundaries between concepts.

### Cross-reference with code

When the user states how something works, check whether the code agrees. If
it doesn't, surface it: "Your code cancels entire Orders, but you just said
partial cancellation is possible. Which is right?"

### Update GLOSSARY.md inline

When a term is resolved, update `GLOSSARY.md` right there. Don't batch these
up. `GLOSSARY.md` holds no implementation details: it is not a spec, a scratch
pad or a home for implementation decisions. It is a glossary and nothing else.

### Record decisions sparingly

Only offer to record a decision when all three are true:

1. **Hard to reverse**: the cost of changing your mind later is meaningful
2. **Surprising without context**: a future reader will wonder "why did they do it this way?"
3. **The result of a real trade-off**: there were genuine alternatives and you picked one for specific reasons

If any of the three is missing, skip it.

## Where decisions go

Put a decision where the repo already keeps them, so it is found again:

- **OpenSpec repo** (an `openspec/` directory) and the session is shaping a
  change: add it to that change's `openspec/changes/<name>/design.md` under
  Decisions, with the alternatives considered. A standing rule that outlives
  the change goes in `openspec/constraints.md` where the repo keeps one. If no
  change exists yet, keep the decisions in the session and hand them to
  `opsx:propose` when the user confirms; never run `openspec init`.
- **Existing ADR directory** (`docs/adr/`, `docs/decisions/`, `adr/`): add an
  ADR there, following its numbering width and template.
- **Neither**: create `docs/adr/` lazily with the format in
  `references/adr-format.md`.

Adapted from the `grill-with-docs`, `grilling` and `domain-modeling` skills in
[mattpocock/skills](https://github.com/mattpocock/skills) (MIT, Copyright (c)
2026 Matt Pocock).

## Response Format

These rules govern what you say in chat. They do not apply to content you author —
documents, blog posts, specs, READMEs, PR and commit bodies, code and comments keep their
own conventions, and a checklist a skill defines is not a "list" for the purposes of rule 8.

1. Lead with the action. The first line is something the reader can run or do — not
   context, not a plan, not a description of what you are about to do.
2. Number multi-step work. One bounded action per step. Cut steps that are not needed.
3. Restate state every turn: "step 3 of 5 done", never an assumption that the reader
   remembers where you left off.
4. Make finished work concrete: "login now works with magic links", not "made changes".
5. Give real time estimates ("~15 minutes"), never "shortly" or "a while".
6. Errors are matter-of-fact: cause, then fix. No apology, no softening, no hedging.
7. Suppress tangents. Finish the current thing. A secondary issue is a separate follow-up
   at the end, not an interruption.
8. Cap a list at 5 items. If it is longer, split it into "do now" and "later".
9. No preamble, no recap, no closing pleasantries. Start with the answer, stop when done.
10. End with exactly one concrete next action the reader can do in under two minutes.

Saying "stop adhd mode" or "long form" suspends these rules for the rest of the session.
